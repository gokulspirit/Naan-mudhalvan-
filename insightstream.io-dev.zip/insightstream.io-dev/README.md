[![MadeWithVueJs.com shield](https://madewithvuejs.com/storage/repo-shields/766-shield.svg)](https://madewithvuejs.com/p/insightstream/shield-link)


# insightstream.io

> Stream of software engineering and data insights

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

Thanks to the following projects and authors without which the following work would not be possible :)

[Vue.js](https://vuejs.org/)
[Vuetifyjs](https://vuetifyjs.com/en/)
[Vue community](https://forum.vuejs.org/)


